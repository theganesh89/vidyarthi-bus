import React from 'react';
import { AlternativeTransport } from '../types';
import { Phone, ExternalLink } from 'lucide-react';

interface AlternativeListProps {
  alternatives: AlternativeTransport[];
}

export function AlternativeList({ alternatives }: AlternativeListProps) {
  if (alternatives.length === 0) {
    return (
      <div className="bg-white border border-dashed border-gray-200 rounded-2xl p-6 text-center">
        <p className="text-gray-400 text-sm italic">No alternatives listed for this route yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {alternatives.map((alt) => (
        <div key={alt.id} className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center justify-between shadow-sm">
          <div className="space-y-1">
            <h4 className="font-bold text-sm">{alt.name}</h4>
            <div className="flex items-center gap-2 text-[10px] text-gray-400 font-bold uppercase tracking-wider">
              <span>Shared Auto</span>
              <span>•</span>
              <span>{alt.area}</span>
            </div>
          </div>
          
          <a 
            href={`tel:${alt.contact}`}
            className="bg-blue-50 text-blue-600 p-2 rounded-full hover:bg-blue-600 hover:text-white transition-colors"
          >
            <Phone className="w-5 h-5" />
          </a>
        </div>
      ))}
    </div>
  );
}
