import React from 'react';
import { CrowdReport, CrowdStatus } from '../types';
import { motion } from 'motion/react';
import { Users, User, UserCheck } from 'lucide-react';

interface CrowdMeterProps {
  reports: CrowdReport[];
}

export function CrowdMeter({ reports }: CrowdMeterProps) {
  if (reports.length === 0) {
    return (
      <div className="space-y-4">
        <div className="h-4 bg-gray-100 rounded-full w-full overflow-hidden">
          <div className="h-full bg-gray-200 animate-pulse w-full" />
        </div>
        <p className="text-gray-400 text-sm text-center italic">Waiting for reports...</p>
      </div>
    );
  }

  // Calculate score: EMPTY=0, SEATED=1, FULL=2
  const scoreMap = { [CrowdStatus.EMPTY]: 0, [CrowdStatus.SEATED]: 50, [CrowdStatus.FULL]: 100 };
  const totalScore = reports.reduce((acc, r) => acc + scoreMap[r.status], 0);
  const averageScore = totalScore / reports.length;

  let color = "bg-green-500";
  let label = "Plenty of Seats";
  let Icon = User;

  if (averageScore > 33 && averageScore <= 66) {
    color = "bg-yellow-500";
    label = "Seated / Limited Space";
    Icon = UserCheck;
  } else if (averageScore > 66) {
    color = "bg-red-500";
    label = "Bus is Full";
    Icon = Users;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`${color} p-2 rounded-lg text-white shadow-sm`}>
            <Icon className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg">{label}</span>
        </div>
        <span className="text-sm font-mono font-medium text-gray-500">{Math.round(averageScore)}%</span>
      </div>

      <div className="relative pt-1">
        <div className="overflow-hidden h-4 text-xs flex rounded-full bg-gray-200 shadow-inner">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${averageScore}%` }}
            transition={{ type: "spring", stiffness: 50, damping: 20 }}
            className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center ${color}`}
          />
        </div>
        
        {/* Markers */}
        <div className="flex justify-between mt-2 px-1">
          <span className="text-[10px] text-gray-400 font-bold">EMPTY</span>
          <span className="text-[10px] text-gray-400 font-bold">SEATED</span>
          <span className="text-[10px] text-gray-400 font-bold">FULL</span>
        </div>
      </div>
    </div>
  );
}
