import React, { useState } from 'react';
import { auth } from '../lib/firebase';
import { CrowdStatus } from '../types';
import { dataService } from '../services/dataService';
import { Check, Send, MapPinOff } from 'lucide-react';
import { motion } from 'motion/react';

interface ReportActionsProps {
  routeId: string;
}

export function ReportActions({ routeId }: ReportActionsProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleReport = async (status: CrowdStatus) => {
    if (!auth.currentUser) {
      setError("Please sign in first to report status.");
      return;
    }
    
    if (!auth.currentUser.emailVerified) {
      setError("Please verify your email to report status.");
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      if (!navigator.geolocation) {
        throw new Error("Geolocation not supported");
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          await dataService.submitReport(routeId, status, { lat: latitude, lng: longitude });
          
          setSuccess(true);
          setTimeout(() => setSuccess(false), 3000);
          setIsSubmitting(false);
        },
        (error) => {
          console.error(error);
          setError("Please enable location to report status.");
          setIsSubmitting(false);
        }
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit");
      setIsSubmitting(false);
    }
  };

  const options = [
    { status: CrowdStatus.EMPTY, label: "Seats Available", color: "bg-green-50 border-green-200 text-green-700", hover: "hover:bg-green-100" },
    { status: CrowdStatus.SEATED, label: "Sitting Only", color: "bg-yellow-50 border-yellow-200 text-yellow-700", hover: "hover:bg-yellow-100" },
    { status: CrowdStatus.FULL, label: "No More Seats", color: "bg-red-50 border-red-200 text-red-700", hover: "hover:bg-red-100" },
  ];

  return (
    <div className="space-y-4">
      {error && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 p-3 bg-red-50 text-red-600 text-xs rounded-xl border border-red-100">
          <MapPinOff className="w-4 h-4" />
          <p>{error}</p>
        </motion.div>
      )}

      {success && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 p-3 bg-green-50 text-green-600 text-xs rounded-xl border border-green-100">
          <Check className="w-4 h-4" />
          <p>Thank you! Your report helps other students.</p>
        </motion.div>
      )}

      <div className="grid grid-cols-1 gap-3">
        {options.map((opt) => (
          <button
            key={opt.status}
            onClick={() => handleReport(opt.status)}
            disabled={isSubmitting}
            className={`
              flex items-center justify-between p-4 rounded-2xl border-2 transition-all active:scale-95
              ${opt.color} ${opt.hover} font-bold disabled:opacity-50 disabled:active:scale-100
            `}
          >
            <span>{opt.label}</span>
            {isSubmitting ? (
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                <Send className="w-4 h-4 opacity-50" />
              </motion.div>
            ) : (
              <Send className="w-4 h-4 opacity-50" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
