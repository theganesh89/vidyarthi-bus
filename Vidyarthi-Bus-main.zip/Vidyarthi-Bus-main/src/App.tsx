import React, { useEffect, useState } from 'react';
import { Bus, MapPin, AlertCircle, Phone, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { initFirebase, signInWithGoogle, auth } from './lib/firebase';
import { dataService } from './services/dataService';
import { Route, CrowdReport, CrowdStatus, AlternativeTransport } from './types';
import { CrowdMeter } from './components/CrowdMeter';
import { ReportActions } from './components/ReportActions';
import { AlternativeList } from './components/AlternativeList';
import { onAuthStateChanged, User } from 'firebase/auth';

export default function App() {
  const [routes, setRoutes] = useState<Route[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [reports, setReports] = useState<CrowdReport[]>([]);
  const [alternatives, setAlternatives] = useState<AlternativeTransport[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    async function setup() {
      await initFirebase();
      const fetchedRoutes = await dataService.getRoutes();
      setRoutes(fetchedRoutes);
      setIsLoading(false);
    }
    setup();
  }, []);

  // Attempt to seed data if admin is logged in
  useEffect(() => {
    if (user?.email === "theganesh89@gmail.com") {
      dataService.seedInitialData().then(() => {
        dataService.getRoutes().then(setRoutes);
      });
    }
  }, [user]);

  useEffect(() => {
    if (selectedRoute) {
      const unsubscribe = dataService.subscribeToRecentReports(selectedRoute.id, (newReports) => {
        setReports(newReports);
      });
      
      dataService.getAlternatives(selectedRoute.id).then(setAlternatives);
      
      return () => unsubscribe();
    }
  }, [selectedRoute]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <motion.div 
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="flex flex-col items-center"
        >
          <Bus className="w-12 h-12 text-blue-600 mb-4" />
          <p className="text-gray-500 font-medium font-sans">Connecting to Vidyarthi-Bus...</p>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 pb-20">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4 sticky top-0 z-10 shadow-sm">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-xl">
              <Bus className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">Vidyarthi Bus</h1>
          </div>
          {user ? (
            <img 
              src={user.photoURL || undefined} 
              alt={user.displayName || 'User'} 
              className="w-8 h-8 rounded-full border border-gray-100"
            />
          ) : (
            <button 
              onClick={() => signInWithGoogle()}
              className="text-xs font-bold text-blue-600 border border-blue-100 px-3 py-1.5 rounded-full hover:bg-blue-50 transition-colors"
            >
              Sign In
            </button>
          )}
        </div>
      </header>

      <main className="max-w-md mx-auto px-6 pt-6 space-y-6">
        {/* Route Selection */}
        <section className="space-y-3">
          <label className="text-xs font-bold uppercase tracking-widest text-gray-400">Select Bus Route</label>
          <div className="relative">
            <select 
              value={selectedRoute?.id || ''}
              onChange={(e) => setSelectedRoute(routes.find(r => r.id === e.target.value) || null)}
              className="w-full bg-white border border-gray-200 rounded-2xl px-4 py-4 pr-10 appearance-none shadow-sm focus:ring-2 focus:ring-blue-500 transition-all outline-none font-medium"
            >
              <option value="">Choose a bus...</option>
              {routes.map(r => (
                <option key={r.id} value={r.id}>{r.number} - {r.name}</option>
              ))}
            </select>
            <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
              <MapPin className="w-4 h-4 text-gray-400" />
            </div>
          </div>
        </section>

        {!selectedRoute ? (
          <div className="text-center py-12 space-y-4">
            <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
              <Info className="w-8 h-8 text-blue-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold">No Route Selected</h2>
              <p className="text-gray-500 text-sm">Pick a route above to see real-time crowd status from your fellow students.</p>
            </div>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            {/* Crowd Meter Card */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-bold text-lg">Crowd Meter</h3>
                <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-1 rounded-full font-bold uppercase">Live Updates</span>
              </div>
              
              <CrowdMeter reports={reports} />
              
              <div className="flex items-center gap-2 text-xs text-gray-400 bg-gray-50 p-3 rounded-xl">
                <AlertCircle className="w-4 h-4" />
                <p>Status based on {reports.length} reports in the last 15 minutes.</p>
              </div>
            </div>

            {/* Reporting Section */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Update Status</h3>
              <ReportActions routeId={selectedRoute.id} />
            </div>

            {/* Alternatives */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Alternative Options</h3>
                <Phone className="w-4 h-4 text-gray-400" />
              </div>
              <AlternativeList alternatives={alternatives} />
            </div>
          </motion.div>
        )}
      </main>

      {/* Footer Info */}
      <footer className="max-w-md mx-auto px-6 py-12 text-center text-gray-400 text-xs">
        <p>Vidyarthi-Bus — Community Powered Infrastructure</p>
        <p className="mt-1">Empowering rural students through data.</p>
      </footer>
    </div>
  );
}
