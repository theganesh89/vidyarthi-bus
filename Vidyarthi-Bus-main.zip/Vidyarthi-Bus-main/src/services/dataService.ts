import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  serverTimestamp, 
  onSnapshot,
  Timestamp,
  doc,
  setDoc,
  limit
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Route, CrowdReport, CrowdStatus, AlternativeTransport } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const dataService = {
  async getRoutes(): Promise<Route[]> {
    const path = 'routes';
    try {
      const snapshot = await getDocs(collection(db, path));
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Route));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  subscribeToRecentReports(routeId: string, callback: (reports: CrowdReport[]) => void) {
    const path = 'reports';
    // Logic: Time-out reports after 15 minutes (to keep data fresh)
    const fifteenMinsAgo = new Date(Date.now() - 15 * 60 * 1000);
    
    const q = query(
      collection(db, path),
      where('routeId', '==', routeId),
      where('timestamp', '>=', Timestamp.fromDate(fifteenMinsAgo)),
      orderBy('timestamp', 'desc'),
      limit(20)
    );

    return onSnapshot(q, (snapshot) => {
      const reports = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CrowdReport));
      callback(reports);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
  },

  async submitReport(routeId: string, status: CrowdStatus, location: { lat: number; lng: number }) {
    const path = 'reports';
    if (!auth.currentUser) throw new Error("User must be signed in");

    try {
      await addDoc(collection(db, path), {
        routeId,
        status,
        location,
        timestamp: serverTimestamp(),
        userId: auth.currentUser.uid
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },

  async getAlternatives(routeId: string): Promise<AlternativeTransport[]> {
    const path = 'alternatives';
    try {
      const q = query(collection(db, path), where('routeId', '==', routeId));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AlternativeTransport));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  async seedInitialData() {
    try {
      // Check if routes exist
      const routes = await this.getRoutes();
      if (routes.length === 0) {
        const initialRoutes = [
          { number: "B101", name: "Village Square to Govt College", stops: ["Square", "Market", "College"] },
          { number: "B102", name: "Old Temple to District Hospital", stops: ["Temple", "Gate", "Hospital"] },
          { number: "B201", name: "Railway Station to Science Park", stops: ["Station", "Bridge", "Park"] }
        ];

        for (const r of initialRoutes) {
          const routeRef = doc(collection(db, 'routes'));
          await setDoc(routeRef, r);
          
          await addDoc(collection(db, 'alternatives'), {
            routeId: routeRef.id,
            name: "Raju Shared Auto",
            contact: "+91 98765 43210",
            area: "Near Square"
          });
          await addDoc(collection(db, 'alternatives'), {
            routeId: routeRef.id,
            name: "Shyam Auto Service",
            contact: "+91 87654 32109",
            area: "Market Stand"
          });
        }
      }
    } catch (error) {
      // Silently fail seeding if permissions are missing (not admin)
      console.log("Seeding skipped: ", error instanceof Error ? error.message : "Insufficient permissions");
    }
  }
};
