export enum CrowdStatus {
  EMPTY = "EMPTY",
  SEATED = "SEATED",
  FULL = "FULL",
}

export interface Route {
  id: string;
  number: string;
  name: string;
  stops?: string[];
}

export interface CrowdReport {
  id: string;
  routeId: string;
  status: CrowdStatus;
  location: {
    lat: number;
    lng: number;
  };
  timestamp: any; // Firestore Timestamp
  userId: string;
}

export interface AlternativeTransport {
  id: string;
  routeId: string;
  name: string;
  contact: string;
  area: string;
}
